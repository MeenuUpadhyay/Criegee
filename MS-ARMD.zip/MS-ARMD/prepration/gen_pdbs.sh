#!/bin/bash


dat=`date ++"%c %m %y"`


echo "                          ~  ~"
echo "                        ( O  O )"
echo "     ----------------o00o--()--o00o------------------"
echo "     |                                              |"
echo "     |                                              |"
echo "     |                   Powered by                 |"
echo "     |                                              |"
echo "     |                   @El_jyosa                  |"
echo "     |                                              |"
echo "     |                                              |"
echo "     |                                              |"
echo "     ------------------------------------------------"

echo "  "
echo "Job start at $dat by $USER"
echo "  "




#################################################################
#                                                               #
#                   FUnction Usage	                            #
#                                                               #
#################################################################


usage(){

	echo "Usage:   $0 pdbfile.pdb $1 template_atoms $2 gaussian_options $3 Energy ground state in au $4 number_of_atoms $5 template_pdb"
	exit 1
}

################################################################


#################################################################
#                                                               #
# This function transform a trajectory file (pdb format) into   #
# gaussian input file. If u want to change the basis set just   #
# change the input file in this script                          #
#                                                               #
#################################################################


function  transform(){


for_split=`echo $1 | awk '{print $1+1}'`
split -l $for_split -a 6 -d $2 $name_proj

if [ -d "gaussian" ]
then 
    rm -rf gaussian
    echo "creating gaussian folder..."
    mkdir gaussian
else
	echo "creating gaussian folder..."
	mkdir gaussian
fi

mv $name_proj.pdb  pdb_backup

mv $name_proj* gaussian

cd gaussian

for i in `ls *`
do
	cat $i > $i.temp1
    rm $i  
    echo $i  
done

echo "  " > template2

echo ""

for i in `ls *.temp1`
do
	Name=`echo $i | cut -d . -f1`
    cat $Name.temp1  | sed -e '$d' | awk '{printf q"%-3.5f   %-3.5f    %3.5f\n", $7,$8,$9}' > $Name.temp2
    rm $Name.temp1
    paste ../$3 $Name.temp2 > $Name.temp3
    cat ../$4 $Name.temp3 template2 > $Name.com
    echo $Name
    rm $Name.temp2 $Name.temp3
done
rm  template2 

cd ..

mv  pdb_backup  $name_proj.pdb
mv  psf_backup  $name_proj.psf



}

###################################################################################
#                                                                                 # 
#                         END transform FUNCTION                                  #
#                                                                                 #
###################################################################################





##################################################################################
#                                                                                #
# Funtion Submit, this functions allows you to submit the gaussian job to        #
# the server where gaussian is located, it waits 5 min until < than 100 jobs     #
# are complete, once all the jobs are done, it return all the output files to    #
# the local computer. (server MAIA)                                              #
#                                                                                #
##################################################################################



function submit(){


#####################################
#                                   #
#              clustername          #
#                                   #
#####################################


usuario=username #adapt
ssh_par=cluster login id #adapt`
gauss_bin=/usr/local/bin/gsub
job_name_key=$name_proj

#for runing local set the variable corr to 0 corr=0
corr=1
echo $corr
if [ $corr -eq 0 ]
then
	cd gaussian
	for i in `ls *.com`
	do
		Name=`echo $i | cut -d . -f1`
		echo "  "
		num=`ls *.out -1 | wc -l`
		tot=`ls *.com -1 | wc -l`
		rem=`echo $num | awk '{print '$tot'-$1 }'`
		echo "Number of computed molecules = $num still $rem molecules has to be computed, patience!!!!!!!!!!"
		echo " "
		echo "processing the gaussian following job:"
		echo " "
		echo "g09 < $Name.com > $Name.out"
		/home/jyosa/programs/g09/g09 < $Name.com > $Name.out
	done
	cd ..
	
else
	ssh $ssh_par "rm -rf gaussian"

	scp -r gaussian $ssh_par:~

	cd gaussian

	for i in `ls *.com`
	do
		Name=`echo $i | cut -d . -f1`
	

	#change the path of G1 if is necessary

		ssh $ssh_par "cd gaussian

		$gauss_bin $Name.com"

	#Change the user name in the server usuario variable

    
		if [ `ssh $ssh_par "squeue | grep -c $usuario"` -ge "300" ]
		then 
			sleep 3m
		fi
	done

  how_many=0
#	while [ `ssh $ssh_par "squeue | grep -c $job_name_key"` -ne "0" ]
	while [ $how_many  -gt 0 ]
	do
	    echo "      "
	    how_many=`ssh $ssh_par "squeue | grep 'username '"` #adapt
	    echo "Jobs with this name $how_many"
	    echo "Waiting....still $how_many molecules are running, you can go for a coffe in the meantime"
	    echo "      "
	    sleep 5m
	done
	
	cd ..

	rm -r gaussian/


	#change the path if is neccesary, for the one in your local computer

	scp -r $ssh_par:~/gaussian .
fi

}

###################################################################################
#                                                                                 # 
#                         END SUBMIT FUNCTION                                     #
#                                                                                 #
###################################################################################




###################################################################################
#                                                                                 # 
#                 Extract energy from gaussian output file function               #
#                 Change the energy in the groun state E_gs                       #
###################################################################################


function extrac_energy(){
	
	if [ -f "energies.txt" ]
	then
		rm energies.txt
	fi
	
	E_gs=$1
	for i in `ls gaussian/*.out` 
	do 
	    Name=`echo $i | cut -d . -f1`
	    cat $Name.out | grep "EUMP2" | tail -1 | awk '{print $6}' | sed 's/D/e/' | awk '{print ($0-('$E_gs'))*627.5095}' >> bb
	    energy=`cat $Name.out | grep "EUMP2" | tail -1 | awk '{print $6}' | sed 's/D/e/'| awk '{print ($1-('$E_gs'))*627.5095}'`
	    echo "$Name   $energy"
	    echo "$Name.com" >> aa
	done

	paste aa bb > energies.txt
	rm aa bb

    if [ -e "energy_raw.dat" ]
    then
	rm energy_raw.dat
    fi
    
    for i in `ls gaussian/*.out` 
    do 
	Name=`echo $i | cut -d . -f1`
	cat $Name.out | grep "SCF Done" | awk '{print $5}' >> energy_raw.dat
    done


	succgod=`cat energies.txt | awk '{print NR}' | tail -1`

	echo "A total of $succgod energies where printed out"

}

###################################################################################
#                                                                                 # 
#              END Extract energy from gaussian output file function              #
#                                                                                 #
###################################################################################





###################################################################################
#                                                                                 # 
#              Create PDBs out of gaussian files                                  #
#                                                                                 #
###################################################################################

function pdbcreation(){

name=$name_proj
dire=gaussian
lista=energies.txt
for_split=`cat $1 | awk '{if ($1 == "END") print NR}' | head -1`

rm -rf pdb
if [ -e "energies_MP2.dat" ]
then 
    rm energies_MP2.dat
else
	 echo "Energy file does nor exist, there is nothing to do"
fi

if [ -d "pdb" ]
then
    echo "There is a directory with the same name.... Deleting pdb dir"
	rm -rf pdb
else
	mkdir pdb
fi

act_atom_name=`cat $1 | awk '{if ( NR < '$for_split') print $4}' | tail -1`
real_atom_name=`cat $2 | awk '{if (NR == 9) print $4}'`


echo "TER
END" > endi

num_atoms=`echo $for_split | awk '{print $0+7}'`

ini=1
fin=`cat $lista | wc -l | awk '{print $1+1}'`
while [ $ini != $fin ]
do
    structure=`cat $lista | awk '{if (NR=='$ini') print $1}'`
    energy=`cat $lista | awk '{if (NR=='$ini') print $2}'`
    Name=`echo $structure | cut -d . -f1`
    cat $Name.com | awk '{if (NR > 8 && NR<='$num_atoms') print $2, $3, $4}' > $Name.t1
    paste $3 $Name.t1 | awk '{printf "%-6s%5d %-2s  %5s%5d     %7.3f %7.3f %7.3f\n", $1, $2, $3, $4, $5, $6, $7, $8}' > $Name.t2
    echo "TITLE     Sulfuric acid 
    REMARK    File generate by El_jyosa for $USER" E=$energy > inic
    cat inic $Name.t2 endi > pdb/$name$ini.pdb
    echo $energy >> charmm_energy.dat 
    rm $Name.t1 $Name.t2 inic
    let ini=$ini+1
    echo "pdb file will be created for $Name $for_split"
done

cat charmm_energy.dat | wc -l > total
cat total charmm_energy.dat > energies_MP2.dat
rm  charmm_energy.dat total

}



###################################################################################
#                                                                                 # 
#             END Create PDBs out of gaussian files                               #
#                                                                                 #
###################################################################################





###################################################################################
#                                                                                 # 
#            Main Program                                                         #
#                                                                                 #
###################################################################################

date1=$(date +"%s")
twee=`which twitter`
hour=`date -u`



name_proj=`echo $1 | cut -d . -f1`

if [ $# != 6 ]
then
	usage
fi 



echo "transforming the pdb file originally from VMD"
echo "  "
echo "    "   

if [ -f "$1" ]
then
	y_n=`cat $1 | grep -c "CRYST1"`
	if [ $y_n -gt 0 ]; then
		cat $1 | awk '{if (NR >= 2) print $0}' > aa
		mv aa $1
	else
		echo "No header for this file"
		echo "  "
	fi
else
	echo "There is not pdb file to proceed..."
	exit 1
fi

#calling transform function 

transform $5 $1 $2 $3




cuantas=`ls -1 gaussian/*.com | wc -l`

echo ""
echo "Proccesing $cuantas structures, $hour"



#calling submit function

submit


cd gaussian
mkdir temp
mv *.out temp
mv *.com temp
mv temp ../
cd ..
rm -rf gaussian
mv temp gaussian
cd gaussian
    

comple_out=`ls *.out | wc -l`
comple_in=`ls *.com | wc -l`
if [ $comple_out -eq $comple_in ]; then
	echo "All the calculation on maia were successfully completed"
else
    donde=pwd
	echo "some calculations were not finished check $donde/fail_calc.txt"
fi


for i in `ls *.out` 
do
    Name=`echo $i | cut -d . -f1`
    succ=`cat $Name.out | grep -c "Normal termination of Gaussian"`
	if [ $succ -eq 0 ]; then
	    echo "not calculation for $Name"
        rm $Name.out $Name.com
        echo "NOT ALL THE CALCULATION WERE DONE ON GAUSSIAN RENUMBERING FILES..."
   	else
	    echo "Calculation for $Name.out was done successfully... pdb files will be created"
	    echo "   "
	fi
done

valor=1
for i in `ls *.com`
do
	Name=`echo $i | cut -d . -f1`
	mv $Name.out $name_proj$valor.out 
	mv $Name.com $name_proj$valor.com
	echo "Moving $Name.out into $name_proj$valor.out and $Name.com into  $name_proj$valor.com"
	let valor++
done


cd ..




#calling function extrac_energy

extrac_energy $4

#caling pdb creation function

pdbcreation $1 $2 $6



#finish and send tweet to El_jyosa

date2=$(date +"%s")
diff=$(($date2-$date1))
min=$(($diff / 60))
sec=$(($diff % 60))


echo "  "
echo "This is the level you have to apply in the fitting procedure : $level"

echo " "
echo "Finish  $date2 total time $min and $sec"







