#!/bin/bash



echo "* CHARmm input file
*
BOMLev -1

!alias
set name p 
set topp ../toppar
set pdbs ../md-product/pdb

!===================================================================
!  Topology and parameter files read in
!===================================================================


OPEN UNIT 1 CARD READ NAME @topp/p.rtf
READ RTF CARD UNIT 1
CLOSE UNIT 1

!---Parameters
OPEN UNIT 1 FORMatted READ NAME @topp/p.par
READ PARAmeter CARD UNIT 1
CLOSE UNIT 1

OPEN READ FORMatted UNIT 1 NAME @topp/lig.psf
READ PSF CARD UNIT 1
CLOSe UNIT 1

OPEN READ FORMatted UNIT 1 NAME @topp/p.pdb
READ COOR PDB UNIT 1
CLOSe UNIT 1


 prnlev 6

!############# ARMD ####################################################
 UPDATE
 OPEN UNIT 14 WRITE   FORMATTED NAME test.pdb
 OPEN UNIT 9 READ FORMATTED NAME cross.dat 
 MRMD UPAR 9 UCRG 14 PRCA 1  PRDY 100
!########################################################################

!===============================================
! Structures 
!===============================================


set n 1
 LABEL ALOP
   READ COOR PDB name @pdbs/ch2chooh_100@n.pdb
 ENERGY
   INCR n BY 1
 IF n LE 196 GOTO ALOP

set n 1
 LABEL cLOP
   READ COOR PDB name ../md-product2/pdb/ch2chooh_100@n.pdb
 ENERGY
   INCR n BY 1
 IF n LE 195 GOTO cLOP


 set n 22
 LABEL BLOP
 prnlev 6
  READ COOR PDB name ../../pdb/irc@n.pdb
ENERGY
 INCR n BY 1
IF n LE 49 GOTO BLOP


STOP"  > rmd-scan.inp
c42b2 < rmd-scan.inp > rmd-scan.out

cat rmd-scan.out | awk '/ENER>/ {printf "%3.10f \n", $3}' > rmd-energy


cat rmd-energy | wc -l > bb
cat bb rmd-energy > energies_CHARMM.dat
rm  bb
